package jm.task.core.jdbc;

import jm.task.core.jdbc.dao.UserDao;
import jm.task.core.jdbc.dao.UserDaoHibernateImpl;
import jm.task.core.jdbc.dao.UserDaoJDBCImpl;
import jm.task.core.jdbc.model.User;
import jm.task.core.jdbc.util.Util;

import java.sql.*;
import java.util.Iterator;


public class Main {
    public static void main(String[] args) throws SQLException {
        // реализуйте алгоритм здесь
        UserDao u1 = new UserDaoJDBCImpl();
        u1.createUsersTable();
        u1.saveUser("Vasya","Pupkin", (byte)23);
        u1.saveUser("Petya","Ivanov", (byte)33);
        u1.saveUser("test","test", (byte)1);
        u1.saveUser("last","lastovich", (byte)5);
        Iterator<User> iterator = u1.getAllUsers().iterator();
        while (iterator.hasNext()){
            System.out.println(iterator.next().toString());
        }
        u1.cleanUsersTable();
        u1.dropUsersTable();

    }
}
